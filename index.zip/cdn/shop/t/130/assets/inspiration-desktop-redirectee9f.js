var path = location.pathname;
if(path === "/collections/inspiration" && window.innerWidth > 768){
 location.href = `${location.origin}`
}  